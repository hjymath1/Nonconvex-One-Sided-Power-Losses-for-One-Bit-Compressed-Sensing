#!/usr/bin/env bash
set -euo pipefail

python experiments/run_p_sweep.py
python experiments/run_mechanism.py
python experiments/run_init_support.py
python experiments/run_support_recovery.py
python experiments/run_flip_fraction.py
python experiments/run_aopf_comparison.py
python experiments/run_aopf_comparison.py --measurement-scaling
python experiments/run_measurement_scaling.py

from __future__ import annotations
import numpy as np
from .utils import sign_nonzero, unit_normalize


def generate_sparse_signal(n: int, s: int, rng: np.random.Generator) -> np.ndarray:
    support = rng.choice(n, size=s, replace=False)
    x = np.zeros(n)
    x[support] = rng.standard_normal(s)
    return unit_normalize(x)


def generate_problem(
    n: int,
    s: int,
    m: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x_star = generate_sparse_signal(n, s, rng)
    A = rng.standard_normal((m, n))
    analog = A @ x_star
    y_clean = sign_nonzero(analog)
    margins = np.abs(analog)
    return A, x_star, y_clean, margins


def corrupt_signs(
    y_clean: np.ndarray,
    margins: np.ndarray,
    q: float,
    mode: str,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    if not (0.0 <= q <= 1.0):
        raise ValueError("q must lie in [0, 1].")
    m = y_clean.size
    k = int(np.rint(q * m))
    y = y_clean.copy()

    if mode == "clean" or k == 0:
        return y, np.empty(0, dtype=int)
    if mode == "random":
        idx = rng.choice(m, size=k, replace=False)
    elif mode == "high":
        idx = np.argsort(margins)[-k:]
    elif mode == "low":
        idx = np.argsort(margins)[:k]
    else:
        raise ValueError("mode must be one of: clean, random, high, low")

    y[idx] *= -1.0
    return y, np.asarray(idx, dtype=int)

from __future__ import annotations
from pathlib import Path
import csv
import numpy as np


def sign_nonzero(x: np.ndarray) -> np.ndarray:
    out = np.where(x >= 0.0, 1.0, -1.0)
    return out.astype(float, copy=False)


def hard_threshold(x: np.ndarray, s: int) -> np.ndarray:
    if s <= 0 or s > x.size:
        raise ValueError("s must satisfy 1 <= s <= len(x)")
    if s == x.size:
        return x.copy()
    idx = np.argpartition(np.abs(x), -s)[-s:]
    out = np.zeros_like(x)
    out[idx] = x[idx]
    return out


def unit_normalize(x: np.ndarray) -> np.ndarray:
    nrm = np.linalg.norm(x)
    if nrm == 0:
        raise FloatingPointError("Cannot normalize a zero vector.")
    return x / nrm


def correlation_initialization(A: np.ndarray, y: np.ndarray, s: int) -> np.ndarray:
    x0 = hard_threshold(A.T @ y / A.shape[0], s)
    return unit_normalize(x0)


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_rows_csv(path: str | Path, rows: list[dict]) -> None:
    path = Path(path)
    if not rows:
        return
    ensure_dir(path.parent)
    keys = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)

from __future__ import annotations
import numpy as np


def normalized_angular_error(x_hat: np.ndarray, x_star: np.ndarray) -> float:
    c = float(np.dot(x_hat, x_star))
    c = float(np.clip(c, -1.0, 1.0))
    return float(np.arccos(c) / np.pi)


def support(x: np.ndarray, s: int | None = None) -> np.ndarray:
    if s is None:
        return np.flatnonzero(x)
    return np.argpartition(np.abs(x), -s)[-s:]


def support_exact(x_hat: np.ndarray, x_star: np.ndarray, s: int) -> float:
    a = set(support(x_hat, s).tolist())
    b = set(support(x_star, s).tolist())
    return float(a == b)


def support_overlap(x_hat: np.ndarray, x_star: np.ndarray, s: int) -> float:
    a = set(support(x_hat, s).tolist())
    b = set(support(x_star, s).tolist())
    return len(a & b) / float(s)

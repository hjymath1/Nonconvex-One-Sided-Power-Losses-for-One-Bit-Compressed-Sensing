from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .utils import hard_threshold, unit_normalize, correlation_initialization, sign_nonzero


@dataclass
class IterationRecord:
    iteration: int
    residuals: np.ndarray
    weights: np.ndarray
    violated: np.ndarray
    x: np.ndarray


def _step(
    A: np.ndarray,
    y: np.ndarray,
    x: np.ndarray,
    s: int,
    p: float,
    epsilon: float,
    mu: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    signed = y * (A @ x)
    residuals = np.maximum(-signed, 0.0)
    violated = residuals > 0.0
    weights = (1.0 + residuals / epsilon) ** (p - 1.0)

    if np.any(violated):
        correction = A[violated].T @ (weights[violated] * y[violated])
        z = x + (mu / A.shape[0]) * correction
    else:
        z = x.copy()

    u = hard_threshold(z, s)
    x_next = unit_normalize(u)
    return x_next, residuals, weights, violated


def oslp_biht(
    A: np.ndarray,
    y: np.ndarray,
    s: int,
    p: float = 0.6,
    epsilon: float = 0.2,
    mu: float = 2.0,
    iterations: int = 200,
    x0: np.ndarray | None = None,
    return_history: bool = False,
):
    if not (0.0 < p <= 1.0):
        raise ValueError("p must satisfy 0 < p <= 1.")
    if epsilon <= 0:
        raise ValueError("epsilon must be positive.")
    if mu <= 0:
        raise ValueError("mu must be positive.")

    x = correlation_initialization(A, y, s) if x0 is None else unit_normalize(x0)
    history: list[IterationRecord] = []

    for t in range(iterations):
        x, residuals, weights, violated = _step(A, y, x, s, p, epsilon, mu)
        if return_history:
            history.append(
                IterationRecord(
                    iteration=t,
                    residuals=residuals.copy(),
                    weights=weights.copy(),
                    violated=violated.copy(),
                    x=x.copy(),
                )
            )

    return (x, history) if return_history else x


def aopf_oslp(
    A: np.ndarray,
    y: np.ndarray,
    s: int,
    corruption_budget: int,
    p: float = 0.6,
    epsilon: float = 0.2,
    mu: float = 2.0,
    iterations: int = 200,
    x0: np.ndarray | None = None,
    detector_start: int = 5,
):
    # Controlled AOP-style detector as stated in the manuscript algorithm.
    x = correlation_initialization(A, y, s) if x0 is None else unit_normalize(x0)
    detected = np.empty(0, dtype=int)
    h_best = np.inf
    m = A.shape[0]

    L = int(max(0, min(corruption_budget, m)))

    for t in range(iterations):
        if t >= detector_start and L > 0:
            h_t = int(np.sum(sign_nonzero(A @ x) != y))
            if h_t <= h_best:
                det_res = np.maximum(-y * (A @ x), 0.0)
                detected = np.argpartition(det_res, -L)[-L:]
                h_best = h_t

        y_tilde = y.copy()
        if detected.size:
            y_tilde[detected] *= -1.0

        x, _, _, _ = _step(A, y_tilde, x, s, p, epsilon, mu)

    return x

# Reproducibility checklist

## Fixed by the manuscript

The current manuscript explicitly states:

- Gaussian sensing matrices;
- unit-norm `s`-sparse signals;
- default `n=500`, `s=10`, `m=1000`;
- `p in {1, 0.8, 0.6, 0.4, 0.2}`;
- `epsilon=0.2`;
- experimental step size `mu=2`;
- default flip fraction `q=0.1`;
- 50 Monte Carlo trials, median with interquartile ranges;
- paired comparisons using the same signal, sensing matrix, and corrupted bits;
- random, high-margin, and low-margin corruption rules;
- normalized angular error;
- correlation initialization;
- AOP-style detector beginning at iteration 5 with known corruption budget.

## Still to be confirmed by the authors

### Iteration count

The manuscript algorithm accepts an iteration count `T`, but the numerical
section does not state the value used for the reported figures.

This repository uses `T=200` as an explicit placeholder default. Replace it
with the actual value before claiming exact figure-level reproduction.

### Sparse-signal coefficient distribution

The manuscript says "unit-norm s-sparse signals" but does not state the
nonzero-coefficient distribution in the numerical section. This package
uses i.i.d. standard Gaussian nonzero coefficients followed by unit
normalization. If the original experiments used Rademacher or another
distribution, update `generate_sparse_signal` accordingly.

### External baselines

OSL0 and HOW-1s require their original algorithmic specifications or source
code. They are not guessed here.

## Randomness

Trials use NumPy's `Generator` with deterministic `SeedSequence`-based
seeding. The comparison is paired within each trial.

## Output

Every experiment writes raw/aggregated CSV files plus PDF/PNG plots. The
CSV data should be archived together with final-paper figures.

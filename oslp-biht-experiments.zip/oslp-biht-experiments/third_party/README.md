# Third-party baseline adapters

The manuscript cites OSL0 (Dai et al.) and HOW-1s (He et al.) as comparison
methods. The current manuscript source does not provide enough executable
detail to recreate these methods faithfully from the paper text alone.

For a public reproducibility release:

1. obtain the authors' official implementation or implement directly from
   the cited source;
2. record the exact version / commit;
3. wrap the implementation with a function of the form

```python
def solve(A, y, s, *, iterations, **kwargs):
    ...
    return x_hat
```

4. ensure all methods in a trial receive exactly the same `A`, `y`, and
   target sparsity;
5. document any method-specific hyperparameters in the experiment CSV.

Do not label an inferred approximation as OSL0 or HOW-1s without validating
it against the cited method.

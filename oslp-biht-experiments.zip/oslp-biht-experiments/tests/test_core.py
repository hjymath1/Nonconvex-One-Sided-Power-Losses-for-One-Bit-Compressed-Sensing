import numpy as np
from oslp_biht.data import generate_problem, corrupt_signs
from oslp_biht.algorithms import oslp_biht
from oslp_biht.metrics import normalized_angular_error
from oslp_biht.utils import correlation_initialization


def test_corruption_count_and_margin_order():
    rng = np.random.default_rng(1)
    A, x, y, margins = generate_problem(50, 5, 100, rng)
    yr, idxr = corrupt_signs(y, margins, 0.1, "random", rng)
    yh, idxh = corrupt_signs(y, margins, 0.1, "high", rng)
    yl, idxl = corrupt_signs(y, margins, 0.1, "low", rng)
    assert len(idxr) == len(idxh) == len(idxl) == 10
    assert np.min(margins[idxh]) >= np.partition(margins, -10)[-10]
    assert np.max(margins[idxl]) <= np.partition(margins, 9)[9]
    assert np.sum(yr != y) == 10


def test_p1_weights_are_one_on_all_residuals():
    rng = np.random.default_rng(2)
    A, x, y, margins = generate_problem(50, 5, 100, rng)
    y, _ = corrupt_signs(y, margins, 0.1, "high", rng)
    _, hist = oslp_biht(A, y, 5, p=1.0, iterations=2, return_history=True)
    assert np.allclose(hist[0].weights, 1.0)


def test_algorithm_returns_unit_sparse_vector():
    rng = np.random.default_rng(3)
    A, x, y, _ = generate_problem(60, 6, 120, rng)
    xhat = oslp_biht(A, y, 6, p=0.6, iterations=5)
    assert np.isclose(np.linalg.norm(xhat), 1.0)
    assert np.count_nonzero(xhat) <= 6
    assert 0.0 <= normalized_angular_error(xhat, x) <= 1.0


def test_initialization_is_unit_sparse():
    rng = np.random.default_rng(4)
    A, x, y, _ = generate_problem(60, 6, 120, rng)
    x0 = correlation_initialization(A, y, 6)
    assert np.isclose(np.linalg.norm(x0), 1.0)
    assert np.count_nonzero(x0) <= 6

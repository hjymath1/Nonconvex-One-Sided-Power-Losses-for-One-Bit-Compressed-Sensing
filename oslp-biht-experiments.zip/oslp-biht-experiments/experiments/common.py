from __future__ import annotations
import argparse
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from oslp_biht.utils import ensure_dir, write_rows_csv


def base_parser(description: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--trials", type=int, default=50)
    p.add_argument("--iterations", type=int, default=200)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--outdir", type=str, default=str(ROOT / "results"))
    p.add_argument("--quick", action="store_true",
                   help="Use small dimensions for a fast smoke run.")
    return p


def quantiles(values):
    a = np.asarray(values, dtype=float)
    return (
        float(np.quantile(a, 0.25)),
        float(np.median(a)),
        float(np.quantile(a, 0.75)),
    )


def aggregate(records, group_keys, value_key):
    groups = {}
    for r in records:
        key = tuple(r[k] for k in group_keys)
        groups.setdefault(key, []).append(r[value_key])
    rows = []
    for key, vals in groups.items():
        q1, med, q3 = quantiles(vals)
        row = {k: v for k, v in zip(group_keys, key)}
        row.update({"q1": q1, "median": med, "q3": q3, "n_trials": len(vals)})
        rows.append(row)
    return rows


def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt


def save_rows(outdir, name, rows):
    out = ensure_dir(outdir)
    write_rows_csv(out / f"{name}.csv", rows)
    return out


def paired_rng(seed: int, trial: int):
    return np.random.default_rng(np.random.SeedSequence([seed, trial]))

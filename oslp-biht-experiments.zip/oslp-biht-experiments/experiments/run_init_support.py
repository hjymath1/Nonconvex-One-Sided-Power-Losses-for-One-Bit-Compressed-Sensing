from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs
from oslp_biht.utils import correlation_initialization
from oslp_biht.metrics import normalized_angular_error, support_exact

def main():
    ap = base_parser("Correlation-initialization diagnostics.")
    args = ap.parse_args()
    n, s, m = (120, 6, 240) if args.quick else (500, 10, 1000)
    qs = [0.0, 0.05, 0.10, 0.15, 0.20]
    modes = ["random", "high"]
    raw = []

    for trial in range(args.trials):
        rng = paired_rng(args.seed, trial)
        A, x_star, y_clean, margins = generate_problem(n, s, m, rng)
        for mode in modes:
            for q in qs:
                y, _ = corrupt_signs(y_clean, margins, q, mode, rng)
                x0 = correlation_initialization(A, y, s)
                raw.append({
                    "trial": trial, "mode": mode, "q": q,
                    "support_exact": support_exact(x0, x_star, s),
                    "angular_error": normalized_angular_error(x0, x_star),
                })

    out = ensure_dir(args.outdir)
    write_rows_csv(out / "init_diagnostic_raw.csv", raw)
    for metric, name, ylabel in [
        ("support_exact", "init_support_exact_vs_q", "Exact support recovery"),
        ("angular_error", "init_angular_error_vs_q", "Normalized angular error"),
    ]:
        rows = aggregate(raw, ["mode", "q"], metric)
        write_rows_csv(out / f"{name}.csv", rows)
        plt = setup_matplotlib()
        fig, ax = plt.subplots()
        for mode in modes:
            rr = sorted([r for r in rows if r["mode"] == mode], key=lambda z: z["q"])
            ax.plot([r["q"] for r in rr], [r["median"] for r in rr],
                    marker="o", label=mode)
        ax.set_xlabel("Flip fraction q")
        ax.set_ylabel(ylabel)
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / f"{name}.pdf")
        fig.savefig(out / f"{name}.png", dpi=200)
        plt.close(fig)

if __name__ == "__main__":
    main()

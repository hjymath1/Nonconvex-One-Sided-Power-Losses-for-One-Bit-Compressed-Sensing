from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs, oslp_biht

def safe_avg(x):
    return float(np.mean(x)) if np.size(x) else np.nan

def safe_ratio(a, b):
    return float(a / b) if np.isfinite(a) and np.isfinite(b) and b > 0 else np.nan

def main():
    ap = base_parser("Iteration-level weighting diagnostics.")
    args = ap.parse_args()
    n, s, m = (120, 6, 240) if args.quick else (500, 10, 1000)
    q, eps, mu = 0.1, 0.2, 2.0
    ps = [1.0, 0.8, 0.6, 0.4, 0.2]
    raw = []

    for trial in range(args.trials):
        rng = paired_rng(args.seed, trial)
        A, x_star, y_clean, margins = generate_problem(n, s, m, rng)
        y, corrupted = corrupt_signs(y_clean, margins, q, "high", rng)
        cmask = np.zeros(m, dtype=bool); cmask[corrupted] = True

        for p in ps:
            _, hist = oslp_biht(
                A, y, s, p, eps, mu, args.iterations, return_history=True
            )
            for rec in hist:
                v = rec.violated
                cv = cmask & v
                nv = (~cmask) & v

                rw = safe_ratio(safe_avg(rec.weights[cv]), safe_avg(rec.weights[nv]))

                gc = np.linalg.norm(
                    A[cv].T @ (rec.weights[cv] * y[cv])
                ) if np.any(cv) else 0.0
                gn = np.linalg.norm(
                    A[nv].T @ (rec.weights[nv] * y[nv])
                ) if np.any(nv) else 0.0
                rg = float(gc / gn) if gn > 0 else np.nan

                raw.append({
                    "trial": trial, "p": p, "iteration": rec.iteration,
                    "weight_ratio": rw, "correction_ratio": rg,
                })

    out = ensure_dir(args.outdir)
    write_rows_csv(out / "mechanism_raw.csv", raw)

    for metric, filename, ylabel in [
        ("weight_ratio", "mechanism_weights", "Corrupted-to-clean average weight ratio"),
        ("correction_ratio", "mechanism_update", "Corrupted-to-clean correction ratio"),
    ]:
        rows = aggregate(
            [r for r in raw if np.isfinite(r[metric])],
            ["p", "iteration"], metric
        )
        write_rows_csv(out / f"{filename}.csv", rows)
        plt = setup_matplotlib()
        fig, ax = plt.subplots()
        for p in ps:
            rr = sorted([r for r in rows if r["p"] == p], key=lambda z: z["iteration"])
            ax.plot([r["iteration"] for r in rr],
                    [r["median"] for r in rr], label=f"p={p:g}")
        ax.set_xlabel("Iteration")
        ax.set_ylabel(ylabel)
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / f"{filename}.pdf")
        fig.savefig(out / f"{filename}.png", dpi=200)
        plt.close(fig)

if __name__ == "__main__":
    main()

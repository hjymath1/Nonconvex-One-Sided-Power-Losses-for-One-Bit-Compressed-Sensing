from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs, oslp_biht
from oslp_biht.metrics import support_exact, support_overlap

def main():
    ap = base_parser("Support recovery versus p.")
    args = ap.parse_args()
    n, s, m = (120, 6, 240) if args.quick else (500, 10, 1000)
    ps = [1.0, 0.8, 0.6, 0.4, 0.2]
    modes = ["clean", "random", "high", "low"]
    q, eps, mu = 0.1, 0.2, 2.0
    raw = []

    for trial in range(args.trials):
        rng = paired_rng(args.seed, trial)
        A, x_star, y_clean, margins = generate_problem(n, s, m, rng)
        for mode in modes:
            y, _ = corrupt_signs(y_clean, margins, q, mode, rng)
            for p in ps:
                xhat = oslp_biht(A, y, s, p, eps, mu, args.iterations)
                raw.append({
                    "trial": trial, "mode": mode, "p": p,
                    "support_exact": support_exact(xhat, x_star, s),
                    "support_overlap": support_overlap(xhat, x_star, s),
                })

    out = ensure_dir(args.outdir)
    write_rows_csv(out / "support_raw.csv", raw)

    for metric, name, ylabel in [
        ("support_exact", "support_exact", "Exact support recovery"),
        ("support_overlap", "support_overlap", "Normalized support overlap"),
    ]:
        rows = aggregate(raw, ["mode", "p"], metric)
        write_rows_csv(out / f"{name}.csv", rows)
        plt = setup_matplotlib()
        fig, ax = plt.subplots()
        for mode in modes:
            rr = sorted([r for r in rows if r["mode"] == mode], key=lambda z: z["p"])
            ax.plot([r["p"] for r in rr], [r["median"] for r in rr],
                    marker="o", label=mode)
        ax.set_xlabel("Residual exponent p")
        ax.set_ylabel(ylabel)
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / f"{name}.pdf")
        fig.savefig(out / f"{name}.png", dpi=200)
        plt.close(fig)

if __name__ == "__main__":
    main()

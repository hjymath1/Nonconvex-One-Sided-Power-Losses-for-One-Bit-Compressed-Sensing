from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs, aopf_oslp
from oslp_biht.metrics import normalized_angular_error

def main():
    ap = base_parser("Controlled AOPF-BIHT versus AOPF-OSLp.")
    ap.add_argument("--measurement-scaling", action="store_true")
    args = ap.parse_args()

    eps, mu = 0.2, 2.0
    modes = ["random", "high"]
    methods = [("AOPF-BIHT", 1.0), ("AOPF-OSLp", 0.6)]
    raw = []

    if args.measurement_scaling:
        n, s = (160, 6) if args.quick else (1000, 10)
        ms = [120, 180, 240] if args.quick else [300, 500, 750, 1000, 1500, 2000, 2500, 3000]
        q = 0.10
        grid = [("m", m) for m in ms]
    else:
        n, s, m = (120, 6, 240) if args.quick else (500, 10, 1000)
        qs = [0.0, 0.05, 0.10, 0.15, 0.20]
        grid = [("q", q) for q in qs]

    for trial in range(args.trials):
        for key, value in grid:
            local_m = int(value) if key == "m" else m
            local_q = float(value) if key == "q" else 0.10
            rng = paired_rng(args.seed, trial * 10000 + int(1000 * local_q) + local_m)
            A, x_star, y_clean, margins = generate_problem(n, s, local_m, rng)
            for mode in modes:
                y, _ = corrupt_signs(y_clean, margins, local_q, mode, rng)
                L = int(np.rint(local_q * local_m))
                for name, p in methods:
                    xhat = aopf_oslp(
                        A, y, s, L, p, eps, mu, args.iterations
                    )
                    raw.append({
                        "trial": trial, "mode": mode, key: value, "method": name,
                        "angular_error": normalized_angular_error(xhat, x_star),
                    })

    out = ensure_dir(args.outdir)
    if args.measurement_scaling:
        stem = "controlled_mscaling_q10"
        rows = aggregate(raw, ["mode", "m", "method"], "angular_error")
        xkey, xlabel = "m", "Number of measurements m"
    else:
        stem = "controlled_qsweep"
        rows = aggregate(raw, ["mode", "q", "method"], "angular_error")
        xkey, xlabel = "q", "Flip fraction q"

    write_rows_csv(out / f"{stem}_raw.csv", raw)
    write_rows_csv(out / f"{stem}.csv", rows)

    for mode, suffix in [("random", "random"), ("high", "highmargin")]:
        plt = setup_matplotlib()
        fig, ax = plt.subplots()
        for name, _ in methods:
            rr = sorted([r for r in rows if r["mode"] == mode and r["method"] == name],
                        key=lambda z: z[xkey])
            ax.plot([r[xkey] for r in rr], [r["median"] for r in rr],
                    marker="o", label=name)
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Normalized angular error")
        ax.legend()
        fig.tight_layout()
        fname = f"controlled_{suffix}_{'mscaling_q10' if args.measurement_scaling else 'qsweep'}"
        fig.savefig(out / f"{fname}.pdf")
        fig.savefig(out / f"{fname}.png", dpi=200)
        plt.close(fig)

if __name__ == "__main__":
    main()

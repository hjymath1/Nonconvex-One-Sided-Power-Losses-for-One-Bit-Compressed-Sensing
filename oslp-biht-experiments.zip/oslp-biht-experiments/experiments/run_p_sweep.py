from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs, oslp_biht
from oslp_biht.metrics import normalized_angular_error

def main():
    ap = base_parser("Residual exponent sweep.")
    args = ap.parse_args()
    n, s, m = (120, 6, 240) if args.quick else (500, 10, 1000)
    ps = [1.0, 0.8, 0.6, 0.4, 0.2]
    modes = ["clean", "random", "high", "low"]
    q, eps, mu = 0.1, 0.2, 2.0
    records = []

    for trial in range(args.trials):
        rng = paired_rng(args.seed, trial)
        A, x_star, y_clean, margins = generate_problem(n, s, m, rng)
        for mode in modes:
            y, _ = corrupt_signs(y_clean, margins, q, mode, rng)
            for p in ps:
                xhat = oslp_biht(A, y, s, p, eps, mu, args.iterations)
                records.append({
                    "trial": trial, "mode": mode, "p": p,
                    "angular_error": normalized_angular_error(xhat, x_star),
                })

    rows = aggregate(records, ["mode", "p"], "angular_error")
    out = save_rows(args.outdir, "p_sweep", rows)

    plt = setup_matplotlib()
    fig, ax = plt.subplots()
    for mode in modes:
        rr = sorted([r for r in rows if r["mode"] == mode], key=lambda z: z["p"])
        x = [r["p"] for r in rr]
        y = [r["median"] for r in rr]
        lo = [r["median"] - r["q1"] for r in rr]
        hi = [r["q3"] - r["median"] for r in rr]
        ax.errorbar(x, y, yerr=[lo, hi], marker="o", capsize=3, label=mode)
    ax.set_xlabel("Residual exponent p")
    ax.set_ylabel("Normalized angular error")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "p_sweep.pdf")
    fig.savefig(out / "p_sweep.png", dpi=200)
    plt.close(fig)

if __name__ == "__main__":
    main()

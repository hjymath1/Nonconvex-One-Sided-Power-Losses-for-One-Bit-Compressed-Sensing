from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs, oslp_biht
from oslp_biht.metrics import normalized_angular_error

def main():
    ap = base_parser("Measurement-scaling comparison.")
    args = ap.parse_args()
    n, s = (160, 6) if args.quick else (1000, 10)
    ms = [120, 180, 240] if args.quick else [300, 500, 750, 1000, 1500, 2000]
    methods = [("BIHT p=1", 1.0), ("OSLp p=0.6", 0.6), ("OSLp p=0.2", 0.2)]
    modes = ["clean", "random", "high"]
    eps, mu, q = 0.2, 2.0, 0.10
    raw = []

    for trial in range(args.trials):
        for m in ms:
            rng = paired_rng(args.seed, trial * 10000 + m)
            A, x_star, y_clean, margins = generate_problem(n, s, m, rng)
            for mode in modes:
                y, _ = corrupt_signs(y_clean, margins, q, mode, rng)
                for name, p in methods:
                    xhat = oslp_biht(A, y, s, p, eps, mu, args.iterations)
                    raw.append({
                        "trial": trial, "mode": mode, "m": m, "method": name,
                        "angular_error": normalized_angular_error(xhat, x_star),
                    })

    out = ensure_dir(args.outdir)
    write_rows_csv(out / "measurement_scaling_raw.csv", raw)
    rows = aggregate(raw, ["mode", "m", "method"], "angular_error")
    write_rows_csv(out / "measurement_scaling.csv", rows)

    for mode, suffix in [("clean", "clean"), ("random", "random"), ("high", "high_margin")]:
        plt = setup_matplotlib()
        fig, ax = plt.subplots()
        for name, _ in methods:
            rr = sorted([r for r in rows if r["mode"] == mode and r["method"] == name],
                        key=lambda z: z["m"])
            ax.plot([r["m"] for r in rr], [r["median"] for r in rr],
                    marker="o", label=name)
        ax.set_xlabel("Number of measurements m")
        ax.set_ylabel("Normalized angular error")
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / f"measurement_scaling_{suffix}.pdf")
        fig.savefig(out / f"measurement_scaling_{suffix}.png", dpi=200)
        plt.close(fig)

if __name__ == "__main__":
    main()

from __future__ import annotations
from common import *
from oslp_biht import generate_problem, corrupt_signs, oslp_biht
from oslp_biht.metrics import normalized_angular_error

def main():
    ap = base_parser("Flip-fraction sweep for BIHT and finite-p OSLp-BIHT.")
    args = ap.parse_args()
    n, s, m = (160, 6, 240) if args.quick else (1000, 10, 1000)
    qs = [0.0, 0.05, 0.10, 0.15, 0.20]
    methods = [("BIHT p=1", 1.0), ("OSLp p=0.6", 0.6), ("OSLp p=0.2", 0.2)]
    modes = ["random", "high"]
    eps, mu = 0.2, 2.0
    raw = []

    for trial in range(args.trials):
        rng = paired_rng(args.seed, trial)
        A, x_star, y_clean, margins = generate_problem(n, s, m, rng)
        for mode in modes:
            for q in qs:
                y, _ = corrupt_signs(y_clean, margins, q, mode, rng)
                for name, p in methods:
                    xhat = oslp_biht(A, y, s, p, eps, mu, args.iterations)
                    raw.append({
                        "trial": trial, "mode": mode, "q": q, "method": name,
                        "angular_error": normalized_angular_error(xhat, x_star),
                    })

    out = ensure_dir(args.outdir)
    write_rows_csv(out / "flip_fraction_raw.csv", raw)
    rows = aggregate(raw, ["mode", "q", "method"], "angular_error")
    write_rows_csv(out / "flip_fraction.csv", rows)

    for mode, fname in [("random", "flip_fraction_random"),
                        ("high", "flip_fraction_high_margin")]:
        plt = setup_matplotlib()
        fig, ax = plt.subplots()
        for name, _ in methods:
            rr = sorted([r for r in rows if r["mode"] == mode and r["method"] == name],
                        key=lambda z: z["q"])
            ax.plot([r["q"] for r in rr], [r["median"] for r in rr],
                    marker="o", label=name)
        ax.set_xlabel("Flip fraction q")
        ax.set_ylabel("Normalized angular error")
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / f"{fname}.pdf")
        fig.savefig(out / f"{fname}.png", dpi=200)
        plt.close(fig)

if __name__ == "__main__":
    main()
